package com.epic.documentmanager.ui.theme

/**
 * Placeholder agar tidak ada dependensi ke Compose.
 * Dibiarkan kosong karena app memakai layout XML.
 */
object Typography
